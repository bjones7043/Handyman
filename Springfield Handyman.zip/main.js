function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  overlay.style.display = "block";

}
function closeNav() {
 document.getElementById("mySidenav").style.width = "0";
 overlay.style.display = "none";

}